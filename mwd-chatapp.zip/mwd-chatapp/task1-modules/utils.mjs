// ES module: named exports (curly brackets on import) ...
export const PI2 = Math.PI * 2;
export function square(x) {
  return x * x;
}
const cube = (x) => x * x * x;
export { cube as power3 }; // renamed export

// ... and ONE default export (no curly brackets on import, any local name)
export default function hello(name) {
  return `Hello, ${name}! (from ES module)`;
}
