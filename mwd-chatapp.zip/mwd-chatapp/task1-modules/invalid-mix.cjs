const fs = require("fs");
import path from "path"; // SyntaxError in a CommonJS file: Cannot use import statement outside a module
console.log(fs, path);
