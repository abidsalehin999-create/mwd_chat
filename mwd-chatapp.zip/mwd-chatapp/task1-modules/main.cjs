// CommonJS file: require() works, static `import` does not.
const { add, multiply } = require("./math.cjs");
const greet = require("./greeter.cjs"); // "default"-like: gets module.exports directly

console.log("=== CommonJS main ===");
console.log("add(2,3) =", add(2, 3), "| multiply(4,5) =", multiply(4, 5));
console.log(greet("Alice"));

// 1) Using an ES module from CommonJS via dynamic import() -> always works (returns a Promise)
async function useEsmFromCjs() {
  const esm = await import("./utils.mjs");
  console.log("dynamic import():", esm.square(5), esm.power3(2), esm.default("Bob"));
}

// 2) Using require() on an ES module -> works in Node >= 22.12 (synchronous ESM only,
//    no top-level await). Older Node versions throw ERR_REQUIRE_ESM.
function requireEsmFromCjs() {
  try {
    const esm = require("./utils.mjs");
    console.log("require(esm):", esm.square(6), "| default export is under .default ->", esm.default("Carol"));
  } catch (err) {
    console.log("require(esm) failed on this Node version:", err.code);
  }
}

requireEsmFromCjs();
useEsmFromCjs();
