// CommonJS module: several named things via exports
exports.add = (a, b) => a + b;
exports.multiply = (a, b) => a * b;
exports.PI = 3.14159;
