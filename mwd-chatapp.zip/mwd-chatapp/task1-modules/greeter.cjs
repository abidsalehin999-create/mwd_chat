// CommonJS: module.exports = <one value>  ->  closest thing to a "default export"
module.exports = function greet(name) {
  return `Hello, ${name}! (from CommonJS)`;
};
