// ES module file: `import` works, `require` is not defined (unless created manually).
import hello, { square, power3, PI2 } from "./utils.mjs"; // default + named imports
import * as utils from "./utils.mjs"; // namespace import
import greet from "./greeter.cjs"; // CJS module.exports  ->  becomes the DEFAULT import
import { add, multiply } from "./math.cjs"; // named imports from CJS work when Node can detect them
import { createRequire } from "node:module";

console.log("=== ES module main ===");
console.log(hello("Dave"), square(3), power3(3), PI2.toFixed(2));
console.log("namespace import keys:", Object.keys(utils));
console.log(greet("Eve"));
console.log("add(1,2) =", add(1, 2), "| multiply(2,6) =", multiply(2, 6));

// Mixing: `require` does not exist in ESM, but we can create one.
const require = createRequire(import.meta.url);
const math = require("./math.cjs");
console.log("require() created via createRequire:", math.PI);

console.log("typeof require without createRequire would be: ReferenceError (see demo-errors.cjs)");
