// Runs the intentionally broken files and prints what Node says about them.
const { spawnSync } = require("node:child_process");
for (const file of ["invalid-mix.cjs", "invalid-mix.mjs"]) {
  const r = spawnSync(process.execPath, [`${__dirname}/${file}`], { encoding: "utf8" });
  const firstErrorLine = r.stderr.split("\n").find((l) => /Error/.test(l));
  console.log(`${file} -> exit code ${r.status}: ${firstErrorLine}`);
}
