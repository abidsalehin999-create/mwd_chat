import path from "node:path";
const fs = require("fs"); // ReferenceError in an ES module: require is not defined
console.log(fs, path);
