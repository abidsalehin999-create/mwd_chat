# MWD Lab – Node.js, Web Servers, TypeScript ChatApp

Requires Node.js >= 22.12 (`node --version`, `npm --version`).

```bash
npm install          # express, ejs, pug, typescript, tsx, types
```

## Task 0 – Install Node.js / npm
1. Download the LTS installer from https://nodejs.org and install it.
2. Open a new terminal and check:
   ```bash
   node --version
   npm --version
   ```
   (Note: two dashes, `--version`. A typographic dash "–" copied from the task sheet will not work.)

## Task 1 – JS modules (`task1-modules/`)
Run: `npm run task1:commonjs`, `npm run task1:esm`, `npm run task1:errors`.

Files: `.cjs` = CommonJS, `.mjs` = ES module (the extension decides, independent of package.json "type").

**Can `require` and `import` be mixed in one file?**
Not directly. In a CommonJS file a static `import ...` is a `SyntaxError`; in an ES module `require` does not exist (`ReferenceError`) – see `invalid-mix.*` and `npm run task1:errors`. Workarounds:
- in CommonJS: dynamic `import("./x.mjs")` (returns a Promise) – see `main.cjs`
- in ESM: `createRequire(import.meta.url)` gives a `require` function – see `main.mjs`

**Can a CommonJS module `import` an ES module / can an ES module be `require`d?**
- ESM **importing** CommonJS: yes, always. `module.exports` becomes the default import; named imports work if Node can detect the names (`main.mjs`).
- CommonJS **requiring** ESM: not possible in old Node versions (`ERR_REQUIRE_ESM`), but since Node 22.12 `require()` of an ES module works as long as the module has no top-level `await`. The result is the namespace object, so the default export is under `.default`. Dynamic `import()` works in every version.

**Naming principle in ES modules**
- Named exports: `export const a`, `export function f`, `export { x as y }`. They are imported with curly brackets and the **exact exported name**: `import { a, f } from "./m.mjs"`; rename on import with `as`: `import { a as b }`.
- Everything at once: `import * as m from "./m.mjs"` (namespace object).
- Default export: `export default ...` (only one per module) is imported **without** curly brackets and with any name you like: `import anyName from "./m.mjs"`. Both can be combined: `import hello, { square } from "./utils.mjs"`.

**Default export vs. CommonJS**
| | ES modules | CommonJS |
|---|---|---|
| one main value | `export default fn` / `import fn from` | `module.exports = fn` / `const fn = require()` |
| several named values | `export const a`, `import { a }` | `exports.a = ...` / `module.exports = { a }`, `const { a } = require()` |
| loading | static, analysed before running, async capable | dynamic, synchronous, can be called anywhere |
| names on import | default can be renamed freely, named ones must match (or use `as`) | everything is just a normal variable, any name |

`module.exports = value` is the closest equivalent of a default export, and when ESM imports a CommonJS file, `module.exports` is exactly what arrives as the default import.

## Task 2 – Web server (`task2-webserver/`)
- `npm run task2:http` – plain `node:http` server, routes `/`, `/about`, `/contact`, everything else -> 404 (Lorem ipsum HTML). Open http://localhost:3000
- `npm run task2:express` – Express server with the same routes + 404, plus
  - **middleware** `middleware/logger.js`: logs method / URL / status / duration of every request, sets an `X-Response-Time` header and counts requests per route (visible as JSON at `/stats`); `express.static` is used as built-in middleware.
  - **rendering**: `app.set("view engine", "ejs")` and `res.render("page", data)`; views in `views/` (`header.ejs`, `footer.ejs` included with `<%- include('header') %>`).
- `npm run task2:express:pug` – the same server with **Pug** templates (`views-pug/`, layout inheritance with `extends` / `block`).

**EJS vs Pug**
| | EJS | Pug |
|---|---|---|
| syntax | normal HTML with `<%= %>` tags | indentation based, no closing tags |
| learning curve | very low (HTML + JS) | needs learning a new syntax |
| reuse | `include` partials | `extends` / `block` / `mixin` (more powerful) |
| readability for big templates | tags can become noisy | very compact |
| designers can paste HTML | yes | no (must convert) |

Preference: **EJS** – templates are plain HTML, so there is nothing new to learn and existing HTML can be pasted in directly. Pug is shorter and has better layout inheritance, but whitespace errors are easy to make.

## Task 3 – TypeScript chat application (`task3-chat/src/`)
| File | Purpose |
|---|---|
| `shared/models.ts` | `User`, `Message`, `ChatRoom` – used by server **and** client |
| `shared/errors.ts` | `ChatError` with HTTP status |
| `chat-service.ts` | server side: stores users and rooms |
| `server.ts` | Express server + JSON API |
| `client.ts` | client side class `ChatClient` (fetch based) |
| `client-demo.ts` | demo script using `ChatClient` |
| `tests.ts` | unit tests of the classes and service |

Classes
- `User`: `id`, `name`
- `Message`: `id`, `author`, `sentAt`, `text`, `editedAt`; `getText()`, `getEditedAt()`, `edit(text)`, private `validateText(text)` (trims, rejects empty / >1000 chars)
- `ChatRoom`: `name`, `members`, `messages`; `join(user)`, `getMembers()`, `sendMessage(userId, text)`, `getMessages()`, `editMessage(userId, messageId, text)`, `searchMessages(query)`

API (JSON)
| Method | Path | Body | Result |
|---|---|---|---|
| POST | `/api/users` | `{name}` | 201 user |
| GET | `/api/users` | | users |
| GET | `/api/rooms` | | rooms |
| POST | `/api/rooms` | `{name}` | 201 room |
| GET | `/api/rooms/:room` | | room |
| POST | `/api/rooms/:room/join` | `{userId}` | room |
| GET | `/api/rooms/:room/members` | | users |
| GET | `/api/rooms/:room/messages[?search=text]` | | messages |
| POST | `/api/rooms/:room/messages` | `{userId, text}` | 201 message |
| PUT | `/api/rooms/:room/messages/:id` | `{userId, text}` | message (403 if not the author) |

Errors: 400 invalid input, 403 not allowed, 404 not found, 409 conflict.

### Demo / tests for the lab session
```bash
npm run task3:test      # unit tests (no server needed)
npm run task3:server    # terminal 1: starts http://localhost:3000
npm run task3:client    # terminal 2: scripted client demo
```
Or send the requests in `requests.http` from the IDE (VS Code REST Client / IntelliJ) or import them in Postman. `npm run task3:build` compiles to `task3-chat/dist/`.
