// Demo: start the server first (npm run task3:server), then run: npm run task3:client
import { ChatClient } from "./client";

async function main() {
  const alice = new ChatClient();
  const bob = new ChatClient();
  await alice.register("Alice");
  await bob.register("Bob");

  await alice.createRoom("lab-demo");
  await alice.joinRoom("lab-demo");
  await bob.joinRoom("lab-demo");

  const m = await alice.sendMessage("lab-demo", "Hello Bob!");
  await bob.sendMessage("lab-demo", "Hi Alice, how is the lab going?");
  await alice.editMessage("lab-demo", m.id, "Hello Bob! (edited)");

  const all = await bob.getMessages("lab-demo");
  console.log("All messages:");
  all.forEach((x) => console.log(` - ${x.author.name}: ${x.getText()}${x.getEditedAt() ? " (edited)" : ""}`));

  const found = await bob.searchMessages("lab");
  console.log("Search 'lab':", found.map((x) => x.getText()));

  try {
    await bob.editMessage("lab-demo", m.id, "I try to edit Alice's message");
  } catch (e) {
    console.log("Expected error:", (e as Error).message);
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
