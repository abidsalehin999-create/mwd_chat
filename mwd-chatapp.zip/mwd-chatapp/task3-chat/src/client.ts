// Client side: wraps the HTTP API in a typed class (uses the global fetch of browsers / Node 18+).
import { ChatRoomDTO, Message, MessageDTO, User, UserDTO } from "./shared/models";

export class ChatClient {
  private currentUser: User | null = null;

  constructor(private readonly baseUrl: string = "http://localhost:3000") {}

  private async request<T>(method: string, path: string, body?: unknown): Promise<T> {
    const res = await fetch(this.baseUrl + path, {
      method,
      headers: { "Content-Type": "application/json" },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(`HTTP ${res.status}: ${data.error ?? "unknown error"}`);
    return data as T;
  }

  getCurrentUser(): User {
    if (!this.currentUser) throw new Error("Not logged in - call register() first");
    return this.currentUser;
  }

  async register(name: string): Promise<User> {
    this.currentUser = User.fromJSON(await this.request<UserDTO>("POST", "/api/users", { name }));
    return this.currentUser;
  }
  listRooms(): Promise<ChatRoomDTO[]> {
    return this.request("GET", "/api/rooms");
  }
  createRoom(name: string): Promise<ChatRoomDTO> {
    return this.request("POST", "/api/rooms", { name });
  }
  joinRoom(room: string): Promise<ChatRoomDTO> {
    return this.request("POST", `/api/rooms/${encodeURIComponent(room)}/join`, { userId: this.getCurrentUser().id });
  }
  async sendMessage(room: string, text: string): Promise<Message> {
    const dto = await this.request<MessageDTO>("POST", `/api/rooms/${encodeURIComponent(room)}/messages`, {
      userId: this.getCurrentUser().id,
      text,
    });
    return Message.fromJSON(dto);
  }
  async getMessages(room: string): Promise<Message[]> {
    const dtos = await this.request<MessageDTO[]>("GET", `/api/rooms/${encodeURIComponent(room)}/messages`);
    return dtos.map(Message.fromJSON);
  }
  async searchMessages(room: string, query: string): Promise<Message[]> {
    const dtos = await this.request<MessageDTO[]>(
      "GET",
      `/api/rooms/${encodeURIComponent(room)}/messages?search=${encodeURIComponent(query)}`
    );
    return dtos.map(Message.fromJSON);
  }
  async editMessage(room: string, messageId: string, text: string): Promise<Message> {
    const dto = await this.request<MessageDTO>("PUT", `/api/rooms/${encodeURIComponent(room)}/messages/${messageId}`, {
      userId: this.getCurrentUser().id,
      text,
    });
    return Message.fromJSON(dto);
  }
}
