// Model classes shared by server AND client (same file, same data, same methods).
import { ChatError } from "./errors";

export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

// ---------- DTOs: the JSON shape that travels over the API ----------
export interface UserDTO {
  id: string;
  name: string;
}
export interface MessageDTO {
  id: string;
  authorId: string;
  authorName: string;
  sentAt: string; // ISO date
  text: string;
  editedAt: string | null;
}
export interface ChatRoomDTO {
  name: string;
  members: UserDTO[];
  messageCount: number;
}

// ---------- User ----------
export class User {
  constructor(public readonly id: string, public name: string) {
    if (typeof name !== "string" || name.trim() === "") {
      throw new ChatError(400, "User name must not be empty");
    }
    this.name = name.trim();
  }

  static create(name: string): User {
    return new User(generateId(), name);
  }
  static fromJSON(dto: UserDTO): User {
    return new User(dto.id, dto.name);
  }
  toJSON(): UserDTO {
    return { id: this.id, name: this.name };
  }
}

// ---------- Message ----------
export class Message {
  readonly id: string;
  readonly author: User;
  readonly sentAt: Date;
  private text: string;
  private editedAt: Date | null;

  constructor(author: User, text: string, id: string = generateId(), sentAt: Date = new Date(), editedAt: Date | null = null) {
    this.id = id;
    this.author = author;
    this.sentAt = sentAt;
    this.text = Message.validateText(text);
    this.editedAt = editedAt;
  }

  /** Trims the text and rejects empty / too long messages. */
  private static validateText(text: unknown): string {
    if (typeof text !== "string") throw new ChatError(400, "Message text must be a string");
    const trimmed = text.trim();
    if (trimmed === "") throw new ChatError(400, "Message text must not be empty");
    if (trimmed.length > 1000) throw new ChatError(400, "Message text must not exceed 1000 characters");
    return trimmed;
  }

  getText(): string {
    return this.text;
  }
  getEditedAt(): Date | null {
    return this.editedAt;
  }
  edit(text: string): void {
    this.text = Message.validateText(text);
    this.editedAt = new Date();
  }

  static fromJSON(dto: MessageDTO): Message {
    return new Message(
      new User(dto.authorId, dto.authorName),
      dto.text,
      dto.id,
      new Date(dto.sentAt),
      dto.editedAt ? new Date(dto.editedAt) : null
    );
  }
  toJSON(): MessageDTO {
    return {
      id: this.id,
      authorId: this.author.id,
      authorName: this.author.name,
      sentAt: this.sentAt.toISOString(),
      text: this.text,
      editedAt: this.editedAt ? this.editedAt.toISOString() : null,
    };
  }
}

// ---------- ChatRoom ----------
export class ChatRoom {
  private members = new Map<string, User>();
  private messages: Message[] = [];

  constructor(public readonly name: string) {
    if (typeof name !== "string" || name.trim() === "") {
      throw new ChatError(400, "Room name must not be empty");
    }
    this.name = name.trim();
  }

  join(user: User): void {
    if (this.members.has(user.id)) throw new ChatError(409, `${user.name} is already a member of ${this.name}`);
    this.members.set(user.id, user);
  }

  getMembers(): User[] {
    return [...this.members.values()];
  }

  isMember(userId: string): boolean {
    return this.members.has(userId);
  }

  sendMessage(userId: string, text: string): Message {
    const user = this.members.get(userId);
    if (!user) throw new ChatError(403, "Only members can send messages");
    const message = new Message(user, text);
    this.messages.push(message);
    return message;
  }

  getMessages(): Message[] {
    return [...this.messages];
  }

  editMessage(userId: string, messageId: string, text: string): Message {
    const message = this.messages.find((m) => m.id === messageId);
    if (!message) throw new ChatError(404, "Message not found");
    if (message.author.id !== userId) throw new ChatError(403, "Only the author can edit a message");
    message.edit(text);
    return message;
  }

  /** Case-insensitive full-text search in the message texts. */
  searchMessages(query: string): Message[] {
    const q = query.trim().toLowerCase();
    if (q === "") return [];
    return this.messages.filter((m) => m.getText().toLowerCase().includes(q));
  }

  toJSON(): ChatRoomDTO {
    return {
      name: this.name,
      members: this.getMembers().map((u) => u.toJSON()),
      messageCount: this.messages.length,
    };
  }
}
