/** Error that carries an HTTP status code so the API can answer correctly. */
export class ChatError extends Error {
  constructor(public readonly status: number, message: string) {
    super(message);
    this.name = "ChatError";
  }
}
