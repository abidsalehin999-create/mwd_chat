// Unit tests without any framework: npm run task3:test
import assert from "node:assert/strict";
import { ChatService } from "./chat-service";
import { ChatError } from "./shared/errors";
import { ChatRoom, Message, User } from "./shared/models";

let passed = 0;
function test(name: string, fn: () => void) {
  fn();
  passed++;
  console.log(`  ok  ${name}`);
}
function throwsStatus(fn: () => unknown, status: number) {
  assert.throws(fn, (e) => e instanceof ChatError && e.status === status);
}

console.log("User / Message / ChatRoom");
test("user name is trimmed, empty name rejected", () => {
  assert.equal(User.create("  Alice ").name, "Alice");
  throwsStatus(() => User.create("   "), 400);
});

test("message text is trimmed and validated", () => {
  const m = new Message(User.create("A"), "  hi  ");
  assert.equal(m.getText(), "hi");
  throwsStatus(() => new Message(User.create("A"), "   "), 400);
});

test("message edit sets editedAt", () => {
  const m = new Message(User.create("A"), "old");
  assert.equal(m.getEditedAt(), null);
  m.edit("new");
  assert.equal(m.getText(), "new");
  assert.ok(m.getEditedAt() instanceof Date);
});

test("message JSON round trip", () => {
  const m = new Message(User.create("A"), "hello");
  m.edit("hello 2");
  const copy = Message.fromJSON(JSON.parse(JSON.stringify(m)));
  assert.equal(copy.getText(), "hello 2");
  assert.equal(copy.author.name, "A");
  assert.deepEqual(copy.getEditedAt(), m.getEditedAt());
});

test("room: join, send, members", () => {
  const room = new ChatRoom("r");
  const a = User.create("A");
  room.join(a);
  throwsStatus(() => room.join(a), 409);
  room.sendMessage(a.id, "x");
  assert.equal(room.getMembers().length, 1);
  assert.equal(room.getMessages().length, 1);
});

test("room: non-member cannot send", () => {
  throwsStatus(() => new ChatRoom("r").sendMessage("nobody", "x"), 403);
});

test("room: only author can edit, unknown message -> 404", () => {
  const room = new ChatRoom("r");
  const a = User.create("A");
  const b = User.create("B");
  room.join(a);
  room.join(b);
  const m = room.sendMessage(a.id, "mine");
  throwsStatus(() => room.editMessage(b.id, m.id, "hack"), 403);
  throwsStatus(() => room.editMessage(a.id, "unknown", "x"), 404);
  room.editMessage(a.id, m.id, "changed");
  assert.equal(room.getMessages()[0].getText(), "changed");
});

test("room: search is case-insensitive", () => {
  const room = new ChatRoom("r");
  const a = User.create("A");
  room.join(a);
  room.sendMessage(a.id, "Hello World");
  room.sendMessage(a.id, "something else");
  assert.equal(room.searchMessages("WORLD").length, 1);
  assert.equal(room.searchMessages("").length, 0);
});

console.log("ChatService");
test("service: default room, create/get rooms and users", () => {
  const s = new ChatService();
  assert.equal(s.listRooms().length, 1);
  s.createRoom("Dev");
  throwsStatus(() => s.createRoom("dev"), 409); // names are case-insensitive
  assert.equal(s.getRoom("DEV").name, "Dev");
  throwsStatus(() => s.getRoom("missing"), 404);
  const u = s.createUser("Zed");
  assert.equal(s.getUser(u.id).name, "Zed");
  throwsStatus(() => s.getUser("nope"), 404);
});

console.log(`\n${passed} tests passed`);
