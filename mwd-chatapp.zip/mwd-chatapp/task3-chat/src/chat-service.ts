// Server side: keeps all users and rooms in memory.
import { ChatError } from "./shared/errors";
import { ChatRoom, User } from "./shared/models";

export class ChatService {
  private users = new Map<string, User>();
  private rooms = new Map<string, ChatRoom>();

  constructor() {
    this.createRoom("general"); // default room
  }

  // users
  createUser(name: string): User {
    const user = User.create(name);
    this.users.set(user.id, user);
    return user;
  }
  getUser(id: string): User {
    const user = this.users.get(id);
    if (!user) throw new ChatError(404, `User ${id} not found`);
    return user;
  }
  listUsers(): User[] {
    return [...this.users.values()];
  }

  // rooms
  private static key(name: string): string {
    return String(name).trim().toLowerCase();
  }
  createRoom(name: string): ChatRoom {
    const room = new ChatRoom(name);
    const key = ChatService.key(name);
    if (this.rooms.has(key)) throw new ChatError(409, `Room ${name} already exists`);
    this.rooms.set(key, room);
    return room;
  }
  getRoom(name: string): ChatRoom {
    const room = this.rooms.get(ChatService.key(name));
    if (!room) throw new ChatError(404, `Room ${name} not found`);
    return room;
  }
  listRooms(): ChatRoom[] {
    return [...this.rooms.values()];
  }
}
