// Express web server + JSON API for the chat application.
import express, { NextFunction, Request, Response } from "express";
import { ChatService } from "./chat-service";
import { ChatError } from "./shared/errors";

export function createApp(service: ChatService = new ChatService()) {
  const app = express();
  app.use(express.json()); // parse JSON request bodies

  // simple request logger (middleware)
  app.use((req, _res, next) => {
    console.log(`${req.method} ${req.originalUrl}`);
    next();
  });

  app.get("/", (_req, res) => {
    res.send("<h1>MWD ChatApp API</h1><p>See README.md for the list of endpoints.</p>");
  });

  // ----- users -----
  app.post("/api/users", (req, res) => {
    const user = service.createUser(req.body?.name);
    res.status(201).json(user);
  });
  app.get("/api/users", (_req, res) => {
    res.json(service.listUsers());
  });

  // ----- rooms -----
  app.get("/api/rooms", (_req, res) => {
    res.json(service.listRooms());
  });
  app.post("/api/rooms", (req, res) => {
    const room = service.createRoom(req.body?.name);
    res.status(201).json(room);
  });
  app.get("/api/rooms/:room", (req, res) => {
    res.json(service.getRoom(req.params.room));
  });
  app.post("/api/rooms/:room/join", (req, res) => {
    const room = service.getRoom(req.params.room);
    room.join(service.getUser(req.body?.userId));
    res.status(200).json(room);
  });
  app.get("/api/rooms/:room/members", (req, res) => {
    res.json(service.getRoom(req.params.room).getMembers());
  });

  // ----- messages -----
  app.get("/api/rooms/:room/messages", (req, res) => {
    const room = service.getRoom(req.params.room);
    const search = req.query.search;
    res.json(typeof search === "string" ? room.searchMessages(search) : room.getMessages());
  });
  app.post("/api/rooms/:room/messages", (req, res) => {
    const message = service.getRoom(req.params.room).sendMessage(req.body?.userId, req.body?.text);
    res.status(201).json(message);
  });
  app.put("/api/rooms/:room/messages/:messageId", (req, res) => {
    const message = service
      .getRoom(req.params.room)
      .editMessage(req.body?.userId, req.params.messageId, req.body?.text);
    res.json(message);
  });

  // ----- 404 + error handling -----
  app.use((_req, res) => {
    res.status(404).json({ error: "Route not found" });
  });
  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (err instanceof ChatError) {
      res.status(err.status).json({ error: err.message });
    } else {
      console.error(err);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  return app;
}

if (require.main === module) {
  const PORT = Number(process.env.PORT) || 3000;
  createApp().listen(PORT, () => console.log(`ChatApp API running on http://localhost:${PORT}`));
}
