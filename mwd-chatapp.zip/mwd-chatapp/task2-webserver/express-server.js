// Express web server: same 3 routes + 404, custom middleware, template rendering (EJS or Pug)
const path = require("node:path");
const express = require("express");
const logger = require("./middleware/logger");
const { pages } = require("./lorem");

const PORT = process.env.PORT || 3000;
const ENGINE = process.env.VIEW_ENGINE === "pug" ? "pug" : "ejs"; // npm run task2:express:pug

const app = express();

// --- view engine (express rendering) ---
app.set("view engine", ENGINE);
app.set("views", path.join(__dirname, ENGINE === "pug" ? "views-pug" : "views"));

// --- middleware ---
app.use(logger); // our own middleware (see middleware/logger.js)
app.use(express.static(path.join(__dirname, "public"))); // built-in middleware

// --- routes ---
for (const [route, page] of Object.entries(pages)) {
  app.get(route, (req, res) => res.render("page", page));
}

// extra route that shows the middleware statistics (JSON)
app.get("/stats", (req, res) => res.json(logger.stats));

// 404 handler: runs when no route matched
app.use((req, res) => {
  res.status(404).render("page", { title: "404", heading: "404 - Not found", text: `No route for ${req.path}` });
});

if (require.main === module) {
  app.listen(PORT, () => console.log(`Express server (${ENGINE}): http://localhost:${PORT}`));
}
module.exports = app;
