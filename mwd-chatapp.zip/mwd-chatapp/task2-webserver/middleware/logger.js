// Custom Express middleware: logs method, URL, status code and duration of every request,
// and adds an X-Response-Time header. Also counts requests per route.
const stats = {};

function logger(req, res, next) {
  const start = process.hrtime.bigint();

  // Header must be set before the response is sent -> hook into "writeHead"
  const originalWriteHead = res.writeHead;
  res.writeHead = function (...args) {
    const ms = Number(process.hrtime.bigint() - start) / 1e6;
    res.setHeader("X-Response-Time", `${ms.toFixed(2)}ms`);
    return originalWriteHead.apply(this, args);
  };

  res.on("finish", () => {
    const ms = Number(process.hrtime.bigint() - start) / 1e6;
    stats[req.path] = (stats[req.path] || 0) + 1;
    console.log(`${new Date().toISOString()} ${req.method} ${req.originalUrl} -> ${res.statusCode} (${ms.toFixed(1)} ms)`);
  });

  next(); // hand over to the next middleware / route
}

logger.stats = stats;
module.exports = logger;
