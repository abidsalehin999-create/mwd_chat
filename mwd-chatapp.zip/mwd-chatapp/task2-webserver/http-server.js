// Plain Node.js web server (no framework): 3 routes + 404
const http = require("node:http");
const { pages } = require("./lorem");

const PORT = process.env.PORT || 3000;

function html({ title, heading, text }) {
  return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><title>${title}</title></head>
<body>
  <nav><a href="/">Home</a> | <a href="/about">About</a> | <a href="/contact">Contact</a></nav>
  <h1>${heading}</h1>
  <p>${text}</p>
</body>
</html>`;
}

const server = http.createServer((req, res) => {
  const path = new URL(req.url, `http://${req.headers.host}`).pathname;
  const page = req.method === "GET" ? pages[path] : undefined;

  if (page) {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    res.end(html(page));
  } else {
    res.writeHead(404, { "Content-Type": "text/html; charset=utf-8" });
    res.end(html({ title: "404", heading: "404 - Not found", text: `No route for ${path}` }));
  }
});

server.listen(PORT, () => console.log(`Plain http server: http://localhost:${PORT}`));
module.exports = server;
