// Shared "Lorem ipsum" content for all servers
const LOREM =
  "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.";

const pages = {
  "/": { title: "Home", heading: "Welcome", text: LOREM },
  "/about": { title: "About", heading: "About us", text: LOREM + " " + LOREM },
  "/contact": { title: "Contact", heading: "Contact", text: "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur." },
};

module.exports = { LOREM, pages };
